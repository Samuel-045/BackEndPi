package com.faculdade.faculdade.services;
import com.faculdade.faculdade.entities.Aluno;
import com.faculdade.faculdade.repositories.AlunoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;

@Service
public class DBService {
    @Autowired
    private AlunoRepository alunoRepository;
    @Bean
    public void instanciarDB() {
        DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
        Aluno aluno1 = new Aluno("Marcos Monteiro",
                LocalDateTime.parse("01/08/2022 08:30", formato));
        Aluno aluno2 = new Aluno("Manoel Monteiro",
                LocalDateTime.parse("01/08/2024 11:18", formato));
        Aluno aluno3 = new Aluno("Maria Monteiro",
                LocalDateTime.parse("02/09/2024 08:25", formato));
        alunoRepository.saveAll(Arrays.asList(aluno1, aluno2, aluno3));
    }
}
