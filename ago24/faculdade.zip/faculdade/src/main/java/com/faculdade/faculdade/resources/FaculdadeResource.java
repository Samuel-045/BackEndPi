package com.faculdade.faculdade.resources;

import com.faculdade.faculdade.entities.Aluno;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.swing.*;
@RestController
@RequestMapping(value = "/faculdade")
public class FaculdadeResource {
    @GetMapping(value = "/{ra}")
    public ResponseEntity<Aluno> findById(@PathVariable Integer ra){
        return null;
    }
}

