package com.faculdade.faculdade.repositories;

import com.faculdade.faculdade.entities.Aluno;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AlunoRepository
        extends JpaRepository<Aluno, Integer>{
}
