package com.faculdade.faculdade;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FaculdadeApplicationTests {

	@Test
	void contextLoads() {
	}

}
